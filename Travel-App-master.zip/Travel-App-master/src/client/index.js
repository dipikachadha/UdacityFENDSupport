// import html from "./views/index.html";
// import images
import img from "./media/img/placeholder.jpg";

const myImg = new Image();
myImg.src = img;
document.querySelector("#img-placeholder").appendChild(myImg);

import "./styles/reset.scss";
import "./styles/base.scss";
import "./styles/utilities.scss";
import "./styles/footer.scss";
import "./styles/form.scss";
import "./styles/header.scss";
