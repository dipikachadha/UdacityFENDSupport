import {
  tripInfo
} from "./js/formHandler.js"

import "./styles/styles.scss"
// Event listener to add function to existing HTML DOM element
document.getElementById("generate").addEventListener("click", function() {
  tripInfo()
});
