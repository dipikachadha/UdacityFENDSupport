import { performAction } from '../src/client/js/performAction'

describe("Testing the main funtctionality", () => {
    test("Testing the performAction() function", () => {

        expect(performAction).toBeDefined();
    })
})