import {
  tripInfo
} from "./js/formHandler.js"


// Event listener to add function to existing HTML DOM element
document.getElementById("generate").addEventListener("click", function() {
  tripInfo()
});
