const app = require('./server');

// Setup Server
const port = process.env.PORT || 8081;
app.listen(port, function () {
    console.log(`running on port ${port}!`)
})