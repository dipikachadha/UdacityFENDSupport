import './styles/style.scss';
import {performAction} from './js/app';


// Event listener on generate button
document.getElementById('submit').addEventListener('click', performAction);

export {
    performAction
}