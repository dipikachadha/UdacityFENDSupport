import {handleSubmit} from '../src/client/js/formHandler';

test('testing formHandler', ()=>{
    expect(handleSubmit).toBeDefined();
}) 