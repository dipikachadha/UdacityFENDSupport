const app = require('./index');

// DECLARING THE PORT
const port = 8081;
const server = app.listen(port, () => {
    console.log(`running on localhost: ${port}`);
});
