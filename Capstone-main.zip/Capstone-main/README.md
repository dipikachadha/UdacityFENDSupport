# Capstone
Capstone Project FEND

This program encompasses the final lessons in the Front End developer program. 

The goal of this program is designed to be a rudimentary travel application where the user, yourself, shall choose a date and location and the website
would output the weather for the paramaters given.

The API's used in this appication are:

Geonames
Weatherbit
