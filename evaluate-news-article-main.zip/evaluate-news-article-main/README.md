## Getting started and run
install dependencies
- `npm install`
start project
- `npm run start`
