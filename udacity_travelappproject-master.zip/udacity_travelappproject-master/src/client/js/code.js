export function sum(a, b) {
    return a + b;
  }
  export function validateString(str) {
    return str.length > 0 ? true : false
  }